<?php

namespace Tests\Unit\Models;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UserTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_can_be_created_using_factory()
    {
        $user = User::factory()->create();

        $this->assertDatabaseHas('users', [
            'id' => $user->id,
        ]);
    }

    /** @test */
    public function it_can_be_admin()
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $manager = User::factory()->create(['role' => 'manager']);
        $user = User::factory()->create(['role' => 'user']);

        $this->assertTrue($admin->isAdmin());
        $this->assertFalse($manager->isAdmin());
        $this->assertFalse($user->isAdmin());
    }

    /** @test */
    public function it_can_be_manager()
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $manager = User::factory()->create(['role' => 'manager']);
        $user = User::factory()->create(['role' => 'user']);

        $this->assertFalse($admin->isManager());
        $this->assertTrue($manager->isManager());
        $this->assertFalse($user->isManager());
    }

    /** @test */
    public function it_can_be_generic_user()
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $manager = User::factory()->create(['role' => 'manager']);
        $user = User::factory()->create(['role' => 'user']);

        $this->assertFalse($admin->isUser());
        $this->assertFalse($manager->isUser());
        $this->assertTrue($user->isUser());
    }

    // Add more tests here for relationships, scopes, accessors, mutators, etc.
} 