<?php

namespace Tests\Unit\Models;

use App\Models\Question;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class QuestionTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function it_can_be_created_using_factory()
    {
        $question = Question::factory()->create();

        $this->assertDatabaseHas('questions', [
            'id' => $question->id,
        ]);
    }

    // TODO: Add tests to ensure 100% coverage for the Question model
    // Consider testing relationships (e.g., with Game), scopes, accessors, mutators, etc.
} 