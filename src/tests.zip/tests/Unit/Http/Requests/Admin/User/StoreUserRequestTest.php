<?php

namespace Tests\Unit\Http\Requests\Admin\User;

use App\Http\Requests\Admin\User\StoreUserRequest;
use App\Models\User as UserModel; // Alias to avoid conflict with testing User class
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

class StoreUserRequestTest extends TestCase
{
    use RefreshDatabase;

    private StoreUserRequest $rules;

    protected function setUp(): void
    {
        parent::setUp();
        $this->rules = new StoreUserRequest();
        // Mock authentication for authorize method if needed
        // $adminUser = UserModel::factory()->create(['role' => 'admin']);
        // $this->actingAs($adminUser, 'admin');
    }

    /** @test */
    public function it_is_authorized_for_admin_users() // Adjust based on your actual authorize() method
    {
        $adminUser = UserModel::factory()->create(['role' => 'admin']);
        $this->actingAs($adminUser, 'admin');
        $this->assertTrue($this->rules->authorize());
    }

    /** @test */
    public function it_has_the_correct_rules()
    {
        $expectedRules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'role' => ['required', 'string', 'in:admin,manager,user'], // Assuming these are your roles
            'is_active' => ['sometimes', 'boolean'],
        ];
        $this->assertEquals($expectedRules, $this->rules->rules());
    }

    /** 
     * @test 
     * @dataProvider validationProvider
     */
    public function test_validation($data, $passes, $errors = [])
    {
        $validator = Validator::make($data, $this->rules->rules());
        $this->assertEquals($passes, $validator->passes(), json_encode($validator->errors()));
        if (!$passes) {
            $this->assertEquals($errors, $validator->errors()->messages());
        }
    }

    public static function validationProvider(): array
    {
        return [
            'request_should_fail_when_name_is_missing' => [
                'data' => [/* name missing */ 'email' => 'test@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'user'],
                'passes' => false,
                'errors' => ['name' => ['The name field is required.']]
            ],
            'request_should_fail_when_email_is_not_unique' => [
                'data' => function () {
                    UserModel::factory()->create(['email' => 'existing@example.com']);
                    return ['name' => 'Test User', 'email' => 'existing@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'user'];
                },
                'passes' => false,
                'errors' => ['email' => ['The email has already been taken.']]
            ],
            'request_should_fail_when_password_is_too_short' => [
                'data' => ['name' => 'Test User', 'email' => 'new@example.com', 'password' => 'short', 'password_confirmation' => 'short', 'role' => 'user'],
                'passes' => false,
                'errors' => ['password' => ['The password field must be at least 8 characters.']]
            ],
            'request_should_fail_when_password_confirmation_does_not_match' => [
                'data' => ['name' => 'Test User', 'email' => 'new@example.com', 'password' => 'password123', 'password_confirmation' => 'different', 'role' => 'user'],
                'passes' => false,
                'errors' => ['password' => ['The password field confirmation does not match.']]
            ],
            'request_should_fail_when_role_is_invalid' => [
                'data' => ['name' => 'Test User', 'email' => 'new@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'invalid_role'],
                'passes' => false,
                'errors' => ['role' => ['The selected role is invalid.']]
            ],
            'request_should_pass_with_valid_data_and_is_active_true' => [
                'data' => ['name' => 'Test User', 'email' => 'test@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'manager', 'is_active' => true],
                'passes' => true,
            ],
            'request_should_pass_with_valid_data_and_is_active_false' => [
                'data' => ['name' => 'Test User', 'email' => 'test2@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'user', 'is_active' => false],
                'passes' => true,
            ],
            'request_should_pass_with_valid_data_and_is_active_not_provided' => [
                'data' => ['name' => 'Test User', 'email' => 'test3@example.com', 'password' => 'password123', 'password_confirmation' => 'password123', 'role' => 'admin'],
                'passes' => true, // is_active defaults or is handled by model
            ],
        ];
    }
} 