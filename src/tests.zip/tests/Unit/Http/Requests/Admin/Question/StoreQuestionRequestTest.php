<?php

namespace Tests\Unit\Http\Requests\Admin\Question;

use App\Http\Requests\Admin\Question\StoreQuestionRequest;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Validator;
use Tests\TestCase;

class StoreQuestionRequestTest extends TestCase
{
    use RefreshDatabase;

    private StoreQuestionRequest $rules;

    protected function setUp(): void
    {
        parent::setUp();
        $this->rules = new StoreQuestionRequest();
        // Mock authentication for authorize method if needed
        // For example, if authorize() checks for admin role:
        // $adminUser = User::factory()->create(['role' => 'admin']);
        // $this->actingAs($adminUser, 'admin');
    }

    /** @test */
    public function it_is_authorized_for_admin_users() // Or whatever your authorization logic is
    {
        // This is a basic example. Adjust based on your actual authorize() method.
        // If authorize() simply returns true, this test is straightforward.
        // If it checks user roles, you'll need to mock an authenticated user.
        $adminUser = User::factory()->create(['role' => 'admin']);
        $this->actingAs($adminUser, 'admin');
        $this->assertTrue($this->rules->authorize());
    }

    /** @test */
    public function it_has_the_correct_rules()
    {
        $expectedRules = [
            'game_id' => ['required', 'exists:games,id'],
            'text' => ['required', 'string', 'max:1000'],
            'type' => ['required', 'in:multiple_choice,true_false,short_answer'],
            'options' => ['nullable', 'array', 'required_if:type,multiple_choice'],
            'options.*.text' => ['required_with:options', 'string', 'max:255'],
            'options.*.is_correct' => ['required_with:options', 'boolean'],
            'correct_answer_text' => ['nullable', 'string', 'required_if:type,short_answer'],
            'correct_boolean_answer' => ['nullable', 'boolean', 'required_if:type,true_false'],
            'points' => ['required', 'integer', 'min:1'],
            'time_limit' => ['nullable', 'integer', 'min:5'],
        ];
        $this->assertEquals($expectedRules, $this->rules->rules());
    }

    /** 
     * @test 
     * @dataProvider validationProvider
     */
    public function test_validation($data, $passes, $errors = [])
    {
        $validator = Validator::make($data, $this->rules->rules());
        $this->assertEquals($passes, $validator->passes(), json_encode($validator->errors()));
        if (!$passes) {
            $this->assertEquals($errors, $validator->errors()->messages());
        }
    }

    public static function validationProvider(): array
    {
        // Add comprehensive data providers for various scenarios
        return [
            'request_should_fail_when_game_id_is_missing' => [
                'data' => [/* missing game_id */ 'text' => 'Question text', 'type' => 'multiple_choice'],
                'passes' => false,
                'errors' => ['game_id' => ['The game id field is required.']]
            ],
            // Add more test cases: missing text, invalid type, missing options for multiple_choice, etc.
            'request_should_pass_with_valid_multiple_choice_data' => [
                'data' => [
                    'game_id' => 1, // Assuming a game with ID 1 exists or mock it
                    'text' => 'What is 2+2?',
                    'type' => 'multiple_choice',
                    'options' => [
                        ['text' => '3', 'is_correct' => false],
                        ['text' => '4', 'is_correct' => true],
                    ],
                    'points' => 10,
                ],
                'passes' => true,
            ],
             'request_should_fail_if_options_is_not_array_for_multiple_choice' => [
                'data' => [
                    'game_id' => 1,
                    'text' => 'What is 2+2?',
                    'type' => 'multiple_choice',
                    'options' => 'not-an-array',
                    'points' => 10,
                ],
                'passes' => false,
                'errors' => [
                    'options' => ['The options field must be an array.'],
                ]
            ],
            'request_should_pass_with_valid_true_false_data' => [
                 'data' => [
                    'game_id' => 1, 
                    'text' => 'Is the sky blue?',
                    'type' => 'true_false',
                    'correct_boolean_answer' => true,
                    'points' => 5,
                ],
                'passes' => true,
            ],
            'request_should_fail_if_correct_boolean_answer_missing_for_true_false' => [
                 'data' => [
                    'game_id' => 1, 
                    'text' => 'Is the sky blue?',
                    'type' => 'true_false',
                    // missing correct_boolean_answer
                    'points' => 5,
                ],
                'passes' => false,
                'errors' => ['correct_boolean_answer' => ['The correct boolean answer field is required when type is true false.']]
            ],
             'request_should_pass_with_valid_short_answer_data' => [
                 'data' => [
                    'game_id' => 1, 
                    'text' => 'What is the capital of France?',
                    'type' => 'short_answer',
                    'correct_answer_text' => 'Paris',
                    'points' => 10,
                ],
                'passes' => true,
            ],
            'request_should_fail_if_correct_answer_text_missing_for_short_answer' => [
                 'data' => [
                    'game_id' => 1, 
                    'text' => 'What is the capital of France?',
                    'type' => 'short_answer',
                    // missing correct_answer_text
                    'points' => 10,
                ],
                'passes' => false,
                'errors' => ['correct_answer_text' => ['The correct answer text field is required when type is short answer.']]
            ],
            // You would need to mock the existence of game_id=1 for these tests to pass fully
            // or ensure your test database setup includes such a record.
        ];
    }
} 