<?php

namespace Tests\Unit\Http\Requests\Admin;

use App\Http\Requests\Admin\LoginRequest;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Illuminate\Support\Facades\Validator;

class LoginRequestTest extends TestCase
{
    use RefreshDatabase;

    private LoginRequest $rules;

    protected function setUp(): void
    {
        parent::setUp();
        $this->rules = new LoginRequest();
    }

    /** @test */
    public function it_has_the_correct_rules()
    {
        $this->assertEquals([
            'email' => ['required', 'string', 'email'],
            'password' => ['required', 'string'],
            'remember' => ['boolean'],
        ], $this->rules->rules());
    }

    /** @test */
    public function it_is_authorized()
    {
        $this->assertTrue($this->rules->authorize());
    }

    /** 
     * @test 
     * @dataProvider validationProvider
     */
    public function test_validation($data, $passes, $errors = [])
    {
        $validator = Validator::make($data, $this->rules->rules());
        $this->assertEquals($passes, $validator->passes());
        if (!$passes) {
            $this->assertEquals($errors, $validator->errors()->messages());
        }
    }

    public static function validationProvider(): array
    {
        return [
            'request_should_fail_when_no_email_is_provided' => [
                'data' => ['password' => 'password'],
                'passes' => false,
                'errors' => ['email' => ['The email field is required.']]
            ],
            'request_should_fail_when_email_is_invalid' => [
                'data' => ['email' => 'not-an-email', 'password' => 'password'],
                'passes' => false,
                'errors' => ['email' => ['The email field must be a valid email address.']]
            ],
            'request_should_fail_when_no_password_is_provided' => [
                'data' => ['email' => 'test@example.com'],
                'passes' => false,
                'errors' => ['password' => ['The password field is required.']]
            ],
            'request_should_pass_with_valid_data' => [
                'data' => ['email' => 'test@example.com', 'password' => 'password', 'remember' => true],
                'passes' => true,
            ],
            'request_should_pass_with_valid_data_and_remember_false' => [
                'data' => ['email' => 'test@example.com', 'password' => 'password', 'remember' => false],
                'passes' => true,
            ],
            'request_should_pass_with_valid_data_and_remember_not_provided' => [
                'data' => ['email' => 'test@example.com', 'password' => 'password'],
                'passes' => true,
            ],
        ];
    }
} 