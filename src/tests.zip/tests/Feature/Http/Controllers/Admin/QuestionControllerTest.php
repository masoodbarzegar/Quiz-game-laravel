<?php

namespace Tests\Feature\Http\Controllers\Admin;

use App\Models\User;
use App\Models\Game;
use App\Models\Question;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
// use Inertia\Testing\AssertableInertia as Assert; // Uncomment if using Inertia assertions

class QuestionControllerTest extends TestCase
{
    use RefreshDatabase;

    protected User $adminUser;
    protected User $managerUser;
    protected Game $game;

    protected function setUp(): void
    {
        parent::setUp();
        $this->adminUser = User::factory()->create(['role' => 'admin']);
        $this->managerUser = User::factory()->create(['role' => 'manager']);
        $this->game = Game::factory()->create(); // Create a game for context
    }

    /** @test */
    public function admin_can_access_question_index()
    {
        $this->actingAs($this->adminUser, 'admin');
        $response = $this->get(route('admin.questions.index'));
        $response->assertStatus(200);
        // $response->assertInertia(fn (Assert $page) => $page->component('Admin/Questions/Index'));
    }

    /** @test */
    public function manager_can_access_question_index() // Assuming managers can also view questions
    {
        $this->actingAs($this->managerUser, 'admin'); // or appropriate guard
        $response = $this->get(route('admin.questions.index'));
        $response->assertStatus(200);
        // $response->assertInertia(fn (Assert $page) => $page->component('Admin/Questions/Index'));
    }

    /** @test */
    public function admin_can_create_a_question()
    {
        $this->actingAs($this->adminUser, 'admin');
        $questionData = Question::factory()->make(['game_id' => $this->game->id])->toArray();

        $response = $this->post(route('admin.questions.store'), $questionData);

        $response->assertRedirect(route('admin.questions.index')); // Or to the question's show page
        $this->assertDatabaseHas('questions', ['text' => $questionData['text']]);
    }

    // TODO: Add tests for other actions (show, edit, update, destroy)
    // Test authorization (e.g., can manager create/edit/delete questions?)
    // Test validation for store and update actions
} 