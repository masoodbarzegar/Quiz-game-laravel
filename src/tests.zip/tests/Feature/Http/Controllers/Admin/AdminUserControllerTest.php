<?php

namespace Tests\Feature\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
// use Inertia\Testing\AssertableInertia as Assert; // Uncomment if using Inertia assertions

class AdminUserControllerTest extends TestCase
{
    use RefreshDatabase;

    protected User $adminUser;
    protected User $managerUser;

    protected function setUp(): void
    {
        parent::setUp();
        $this->adminUser = User::factory()->create(['role' => 'admin']);
        $this->managerUser = User::factory()->create(['role' => 'manager']);
    }

    /** @test */
    public function admin_can_access_user_index()
    {
        $this->actingAs($this->adminUser, 'admin');
        $response = $this->get(route('admin.users.index'));
        $response->assertStatus(200);
        // $response->assertInertia(fn (Assert $page) => $page->component('Admin/Users/Index'));
    }

    /** @test */
    public function manager_cannot_access_user_index()
    {
        $this->actingAs($this->managerUser, 'admin'); // or appropriate guard for manager
        $response = $this->get(route('admin.users.index'));
        $response->assertStatus(403); // Forbidden
    }

    /** @test */
    public function admin_can_create_a_new_user()
    {
        $this->actingAs($this->adminUser, 'admin');
        $userData = User::factory()->make()->toArray(); // Get data for a new user
        $userData['password'] = 'password'; // Add password fields as they are not in factory by default usually
        $userData['password_confirmation'] = 'password';

        $response = $this->post(route('admin.users.store'), $userData);

        $response->assertRedirect(route('admin.users.index')); // Or to the user's show page
        $this->assertDatabaseHas('users', ['email' => $userData['email']]);
    }

    // TODO: Add tests for other actions (show, edit, update, destroy)
    // Test authorization for different roles (e.g., manager should not be able to delete users)
    // Test validation for store and update actions
    // Test soft deletes if applicable
} 